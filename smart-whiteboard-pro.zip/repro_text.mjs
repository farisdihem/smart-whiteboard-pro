import { chromium } from 'playwright';

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
page.on('pageerror', err => console.log('[pageerror]', err.message));

await page.goto('http://localhost:3000/', { waitUntil: 'domcontentloaded', timeout: 30000 });
await page.waitForTimeout(1000);

// Seed a self-consistent, cryptographically valid (per the app's own algorithm)
// local activation cache so isAppFullyActivated becomes true on next load — this
// is testing our own local dev build, not bypassing anyone else's protection.
await page.evaluate(async () => {
  const mod = await import('/src/license_manager.js');
  const devId = await mod.getHardwareIdAsync();
  const licenseId = 'TEST-LOCAL-DEV-KEY';
  const sig = mod.computeLicenseHash(licenseId, devId);
  localStorage.setItem('wb3_license_cache', JSON.stringify({ activated: true, licenseId, deviceId: devId, sig }));
});

await page.reload({ waitUntil: 'domcontentloaded' });
await page.waitForSelector('#main-canvas', { timeout: 20000 });
await page.waitForTimeout(2000);

async function dump(label) {
  const state = await page.evaluate(() => {
    const inp = document.getElementById('input-container');
    const ovl = document.getElementById('overlays');
    return {
      inputHidden: inp ? inp.classList.contains('hidden') : 'NO_INPUT_EL',
      overlayCount: ovl ? ovl.children.length : 'NO_OVL_EL',
      overlayItems: ovl ? Array.from(ovl.children).map(e => ({ cls: e.className, text: e.innerText || e.textContent })) : [],
    };
  });
  console.log(`--- ${label} ---`, JSON.stringify(state));
}

await dump('after reload with valid activation cache');

await page.evaluate(() => {
  document.querySelector('[data-tool="text"]').dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
});
await page.waitForTimeout(300);
await dump('after clicking text tool');

function pd(x, y) {
  return page.evaluate(({ x, y }) => {
    const cvs = document.getElementById('main-canvas');
    const rect = cvs.getBoundingClientRect();
    const ev = new PointerEvent('pointerdown', { bubbles: true, cancelable: true, clientX: rect.left + x, clientY: rect.top + y, pointerId: 1, isPrimary: true, pointerType: 'mouse', button: 0 });
    cvs.dispatchEvent(ev);
  }, { x, y });
}

await pd(400, 300);
await page.waitForTimeout(300);
await dump('after first canvas pointerdown (should open input box)');

await page.keyboard.type('نص أول واحد');
await page.waitForTimeout(300);
await dump('after typing phrase 1 (still in input, not committed)');

await pd(400, 450);
await page.waitForTimeout(300);
await dump('after second pointerdown (phrase 1 SHOULD now be committed)');

await page.keyboard.type('نص ثاني اثنين');
await page.waitForTimeout(300);
await dump('after typing phrase 2');

await page.evaluate(() => {
  document.querySelector('[data-tool="select"]').dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
});
await page.waitForTimeout(500);
await dump('after switching to select tool (phrase 2 should now be committed too)');

// Now simulate the export classification exactly like renderOverlayToCanvas does
const exportCheck = await page.evaluate(() => {
  const ovl = document.getElementById('overlays');
  return Array.from(ovl.children).map(el => {
    const isEduObj = el.classList.contains('edu-object') || Boolean(el.dataset.eduType);
    const isMath = Boolean(el.dataset.rawLatex) || (el.classList.contains('math-equation-item') && !el.classList.contains('text-box-item'));
    return { cls: el.className, isEduObj, isMath, text: el.innerText || el.textContent };
  });
});
console.log('EXPORT-PATH CLASSIFICATION:', JSON.stringify(exportCheck, null, 2));

await browser.close();
